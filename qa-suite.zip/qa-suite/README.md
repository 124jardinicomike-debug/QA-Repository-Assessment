# Sauce Demo + restful-booker Test Suite

Automated tests against:
- **UI:** [Sauce Demo](https://www.saucedemo.com) — login, cart, checkout
- **API:** [restful-booker](https://restful-booker.herokuapp.com) — booking CRUD

## How to install and run

```bash
npm install
npx playwright install --with-deps chromium   # first time only

npm test              # everything (UI + API)
npm run test:ui       # UI project only
npm run test:api      # API project only
npm run test:ui:headed  # watch the browser while it runs
npm run report         # open the last HTML report
```

Requires Node 18+. No `.env` or credentials are needed — Sauce Demo's
accounts and restful-booker's admin login are both public demo
credentials documented on the target sites themselves, and are used
as-is in the test code.

> **Note on this environment:** this suite was written and reviewed in
> a sandboxed setting without outbound network access, so I could not
> actually execute `npm install` / `npx playwright test` against the
> live sites before delivering it. Everything below is written and
> structured to run as documented, and selectors/endpoints are based
> on the current public behavior of both apps, but you should treat
> the first real run as the actual verification step, not this
> writeup. If a selector has drifted (e.g. Sauce Demo tweaks a class
> name), it'll fail loud and specific rather than silently — see
> "What I'd add with more time" below for how I'd harden against that.

## Why Playwright

- **One tool, two layers.** Playwright's `request` fixture is a full
  HTTP client independent of the browser, so the same test runner,
  config, reporter, and CI setup covers both the UI and API suites.
  That means one `npm test`, one report, no context-switching between
  a browser tool and a separate REST client library.
- **Auto-waiting.** Sauce Demo's cart badge, error banners, and
  step-to-step navigation all rely on client-side JS state changes.
  Playwright's locators retry until the assertion condition is met
  instead of relying on hard sleeps or manual polling, which is the
  main source of flakiness in Selenium suites for this kind of app.
- **Built-in isolation and debugging.** Each test gets a fresh browser
  context automatically; failures capture a screenshot, video, and
  trace with zero extra setup — useful for a small suite maintained by
  one person without a dedicated test-infra investment.
- **TypeScript.** Page objects give real autocomplete and compile-time
  checking on selectors and method signatures, which matters more as
  the suite grows past a handful of files.

I considered Selenium + a separate API library (e.g. `requests` in
Python or `supertest` in JS), but for a suite this size the two-tool
split adds config and dependency overhead without buying anything —
Playwright's API testing is a first-class feature, not a bolt-on.

## Project structure

```
pages/                     Page Object Model for the UI
  LoginPage.ts
  InventoryPage.ts
  CartPage.ts
  CheckoutPage.ts
tests/ui/
  checkout.spec.ts             happy path: login -> cart -> checkout
  login-negative.spec.ts       locked-out user, bad creds, empty form
  checkout-validation.spec.ts  unhappy path inside a valid session
  known-issues.spec.ts         pins down problem_user's documented bug
tests/api/
  fixtures.ts                  shared types, sample data, auth fixture
  booking-crud.spec.ts         full lifecycle: create/read/update/patch/delete
  booking-negative.spec.ts     bad auth, missing fields, invalid id, no-token writes
playwright.config.ts
```

## What's tested at the UI layer vs. the API layer, and why

**UI (Sauce Demo):**
- Full login → add-to-cart → checkout → confirmation flow, including
  a check that `subtotal + tax == total` on the summary screen.
- `locked_out_user`, invalid credentials, and an empty login form —
  Sauce Demo has no login API to hit, so this behavior only exists in
  the browser.
- Checkout form validation (missing first/last name, missing postal
  code) — this is client-side JS validation with no backend
  equivalent, so it has to be tested where it lives.
- `problem_user`'s broken-image bug, called out explicitly as a named
  regression test rather than left to surface as a confusing failure
  somewhere else.

**What I deliberately *didn't* push through the UI:** there's no login
API for Sauce Demo, so I couldn't move the login cases to the API
layer even if I wanted to — but the general principle I followed is:
if a behavior can be verified via a request/response instead of a
DOM interaction, it belongs in the API suite. The checkout flow is
the one exception, kept as a single full journey because the *thing
being tested* is the multi-step, stateful, client-rendered flow
itself, not just "does data reach the server correctly."

**API (restful-booker):**
- Auth (`POST /auth`) — including the wrong-password case, which
  returns a `200` with a `{"reason": "Bad credentials"}` body instead
  of a `401` (a real quirk worth pinning down explicitly, since it's
  exactly the kind of thing that silently breaks an assumption in a
  client written against "the happy path always returns clean status
  codes").
- Full CRUD lifecycle (`POST` / `GET` / `PUT` / `PATCH` / `DELETE`),
  run serially against the same `bookingid` because that's how a real
  client would use it, and because it verifies persistence — every
  write is followed by an independent `GET` to confirm the change
  actually landed server-side, not just that the response body looked
  right.
- Negative cases: invalid/nonexistent booking id, empty-payload
  create, and unauthenticated `PUT`/`DELETE` (expects `403`, then
  re-`GET`s to confirm the record was left untouched).

This split means the UI suite stays small and only covers things that
are genuinely browser-dependent (client-side state, DOM validation,
rendering bugs), while data correctness, persistence, and auth edge
cases — the things brittle UI tests are usually mis-used for — live in
the much faster, much more stable API suite.

## What I'd add or change with more time

- **CI wiring** (GitHub Actions) running `npm run test:api` on every
  push and `npm run test:ui` on a schedule, since the UI suite is more
  exposed to upstream markup changes.
- **Visual regression** for the `problem_user` bug and the checkout
  summary layout, since "images are identical" is currently checked
  structurally (`src` attributes) rather than visually.
- **A cleanup/teardown hook** for the API suite so a failed run
  doesn't leave orphaned bookings behind — right now cleanup happens
  as a side effect of the delete test itself, which is fine for a
  small demo API but wouldn't scale.
- **Parameterized cross-account UI tests** — Sauce Demo ships
  `performance_glitch_user`, `error_user`, and `visual_user` as well;
  I picked `locked_out_user` and `problem_user` as the two clearest,
  most distinct failure modes to keep the suite focused rather than
  covering all six accounts.
- **Contract-style assertions on the API's error bodies.**
  restful-booker isn't consistent about status codes for malformed
  input (see the empty-create test), so right now that test only
  asserts "not a success," which is honest about what the API
  actually guarantees but weaker than I'd like.
- Actually run the suite against the live sites and fix whatever
  selector or timing issues show up on a real execution, per the note
  at the top of this file.

## Where I used AI tooling

I (Claude) wrote this suite directly as the deliverable, so in one
sense all of it is "AI-authored" — this section is more useful framed
as: what came from documented, verifiable facts about the two apps,
versus what I inferred/assumed and would flag for a human reviewer to
double-check on first run.

**Verified against known, stable facts:**
- Sauce Demo's account list and passwords, the checkout step-by-step
  form flow, and the `problem_user` broken-image bug are all
  documented/observable behavior of the app itself.
- restful-booker's endpoint shapes (`/auth`, `/booking`,
  `/booking/{id}`), its published admin credentials, and its
  `200 + {"reason": "Bad credentials"}` response for bad auth are
  documented quirks of that specific API, not guesses.

**Inferred and would double-check on first real run:**
- Exact current CSS selectors/ids (e.g. `.summary_subtotal_label`,
  `[data-test="error"]`) — these come from the app's known structure
  but front-end markup can drift, and this is the most likely source
  of a first-run failure.
- restful-booker's exact status code for a malformed `PUT`/`GET`
  (e.g. non-numeric id) — I asserted a general "4xx, not 5xx" range
  for the non-numeric-id case rather than a specific code, since I
  wasn't able to confirm the exact value without live access.
- The empty-payload create test intentionally asserts only "not 200"
  rather than a specific status, because restful-booker's behavior for
  malformed create requests isn't cleanly documented and I didn't want
  to hardcode a guessed status code as if it were a confirmed
  contract.

Nothing here needed "correcting" after the fact in the traditional
sense (there was no separate human-written draft to diff against),
but the honest caveat is the one at the top of this file: this suite
has not been executed end-to-end against the live sites, so the real
correction step — fixing whatever a live run surfaces — hasn't
happened yet.
