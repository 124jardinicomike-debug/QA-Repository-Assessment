import { test as base, APIRequestContext, expect } from '@playwright/test';

export interface BookingDates {
  checkin: string;
  checkout: string;
}

export interface Booking {
  firstname: string;
  lastname: string;
  totalprice: number;
  depositpaid: boolean;
  bookingdates: BookingDates;
  additionalneeds?: string;
}

export function sampleBooking(overrides: Partial<Booking> = {}): Booking {
  return {
    firstname: 'Jim',
    lastname: 'Brown',
    totalprice: 111,
    depositpaid: true,
    bookingdates: { checkin: '2026-01-01', checkout: '2026-01-05' },
    additionalneeds: 'Breakfast',
    ...overrides,
  };
}

/**
 * restful-booker's admin credentials are published in its own docs
 * (username: admin / password: password123) -- this is a public demo
 * API with no real secrets, so it's fine to keep this in the repo.
 * A real project would pull this from an env var / secrets manager.
 */
export const ADMIN_CREDENTIALS = { username: 'admin', password: 'password123' };

type Fixtures = {
  authToken: string;
};

export const test = base.extend<Fixtures>({
  // Fetches a fresh auth token once per test that needs it.
  authToken: async ({ request }, use) => {
    const response = await request.post('/auth', { data: ADMIN_CREDENTIALS });
    expect(response.ok()).toBeTruthy();
    const body = await response.json();
    await use(body.token);
  },
});

export { expect };

/** POST /booking and return the parsed response body. */
export async function createBooking(request: APIRequestContext, booking: Booking) {
  const response = await request.post('/booking', { data: booking });
  expect(response.status()).toBe(200);
  return response.json();
}
