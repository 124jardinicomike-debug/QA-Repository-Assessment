import { test, expect, sampleBooking, createBooking, ADMIN_CREDENTIALS } from './fixtures';

test.describe('Booking API - negative cases', () => {
  test('auth: wrong password does not return a usable token', async ({ request }) => {
    // Quirk worth pinning down: restful-booker answers bad credentials
    // with HTTP 200 and a { reason: "Bad credentials" } body instead
    // of a 401/403. The assertion checks the payload, not just status,
    // so this test would still fail loudly if that behavior changes.
    const response = await request.post('/auth', {
      data: { username: ADMIN_CREDENTIALS.username, password: 'definitely-wrong' },
    });
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).not.toHaveProperty('token');
    expect(body.reason).toBe('Bad credentials');
  });

  test('read: GET /booking/{id} for a nonexistent id returns 404', async ({ request }) => {
    const response = await request.get('/booking/999999999');
    expect(response.status()).toBe(404);
  });

  test('read: GET /booking/{id} for a non-numeric id returns a client error, not a 200', async ({ request }) => {
    const response = await request.get('/booking/not-a-valid-id');
    expect(response.status()).toBeGreaterThanOrEqual(400);
    expect(response.status()).toBeLessThan(500);
  });

  test('create: booking missing all required fields is rejected', async ({ request }) => {
    const response = await request.post('/booking', { data: {} });
    // The public API isn't consistent here (no clean 400 contract),
    // but it must not silently succeed with an empty booking -- that's
    // the behavior this test actually guards against.
    expect(response.status()).not.toBe(200);
  });

  test('update: PUT /booking/{id} without an auth token is rejected', async ({ request }) => {
    const created = await createBooking(request, sampleBooking());

    const response = await request.put(`/booking/${created.bookingid}`, {
      data: sampleBooking({ firstname: 'Unauthorized' }),
      // deliberately no Cookie/auth header
    });
    expect(response.status()).toBe(403);

    // Confirm the record was actually left untouched.
    const getResponse = await request.get(`/booking/${created.bookingid}`);
    const persisted = await getResponse.json();
    expect(persisted.firstname).not.toBe('Unauthorized');
  });

  test('delete: DELETE /booking/{id} without an auth token is rejected', async ({ request }) => {
    const created = await createBooking(request, sampleBooking());

    const response = await request.delete(`/booking/${created.bookingid}`);
    expect(response.status()).toBe(403);

    // Confirm it's still there.
    const getResponse = await request.get(`/booking/${created.bookingid}`);
    expect(getResponse.status()).toBe(200);
  });
});
