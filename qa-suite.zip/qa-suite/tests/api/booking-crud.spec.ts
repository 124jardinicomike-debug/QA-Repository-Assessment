import { test, expect, sampleBooking, createBooking } from './fixtures';

/**
 * Full lifecycle against restful-booker: create -> read -> update ->
 * partial update -> delete -> confirm gone. Run as a single serial
 * describe block because each step depends on the booking id created
 * in step one -- that dependency is the point (this mirrors how a
 * real client would use the API), not a workaround.
 */
test.describe.serial('Booking CRUD lifecycle', () => {
  let bookingId: number;
  const created = sampleBooking();

  test('create: POST /booking returns a new booking id and echoes the payload', async ({ request }) => {
    const body = await createBooking(request, created);

    expect(body).toHaveProperty('bookingid');
    expect(typeof body.bookingid).toBe('number');
    expect(body.booking).toMatchObject(created);

    bookingId = body.bookingid;
  });

  test('read: GET /booking/{id} returns exactly what was created', async ({ request }) => {
    const response = await request.get(`/booking/${bookingId}`);
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).toMatchObject(created);
  });

  test('update: PUT /booking/{id} replaces the booking (requires auth)', async ({ request, authToken }) => {
    const updated = sampleBooking({ firstname: 'James', totalprice: 222 });

    const response = await request.put(`/booking/${bookingId}`, {
      data: updated,
      headers: { Cookie: `token=${authToken}` },
    });
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).toMatchObject(updated);

    // Confirm the change actually persisted server-side, not just in
    // the response we were handed.
    const getResponse = await request.get(`/booking/${bookingId}`);
    expect(await getResponse.json()).toMatchObject(updated);
  });

  test('partial update: PATCH /booking/{id} changes only the given fields', async ({ request, authToken }) => {
    const response = await request.patch(`/booking/${bookingId}`, {
      data: { totalprice: 333 },
      headers: { Cookie: `token=${authToken}` },
    });
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body.totalprice).toBe(333);
    expect(body.firstname).toBe('James'); // untouched by the PATCH

    const getResponse = await request.get(`/booking/${bookingId}`);
    const persisted = await getResponse.json();
    expect(persisted.totalprice).toBe(333);
    expect(persisted.firstname).toBe('James');
  });

  test('delete: DELETE /booking/{id} removes the booking (requires auth)', async ({ request, authToken }) => {
    const response = await request.delete(`/booking/${bookingId}`, {
      headers: { Cookie: `token=${authToken}` },
    });
    // restful-booker returns 201 (not 204) on successful delete.
    expect(response.status()).toBe(201);

    const getResponse = await request.get(`/booking/${bookingId}`);
    expect(getResponse.status()).toBe(404);
  });
});
