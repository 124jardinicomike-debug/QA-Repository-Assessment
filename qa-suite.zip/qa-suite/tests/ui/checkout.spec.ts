import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { InventoryPage } from '../../pages/InventoryPage';
import { CartPage } from '../../pages/CartPage';
import { CheckoutPage } from '../../pages/CheckoutPage';

/**
 * End-to-end happy path: log in, add two items, verify the cart,
 * fill in checkout details, and confirm the order.
 *
 * This is the one flow in the suite that's allowed to be a full,
 * multi-step UI journey -- it's the thing a real user actually does,
 * and it exercises state that only exists in the browser (cart badge,
 * client-side tax calculation, page-to-page navigation). Everything
 * that's just "does the backend accept this data" lives in the API
 * suite instead.
 */
test.describe('Checkout - happy path', () => {
  test('standard_user can add items to cart and complete checkout', async ({ page }) => {
    const login = new LoginPage(page);
    const inventory = new InventoryPage(page);
    const cart = new CartPage(page);
    const checkout = new CheckoutPage(page);

    await login.goto();
    await login.login('standard_user', 'secret_sauce');
    await expect(page).toHaveURL(/inventory\.html/);

    await inventory.addItemToCart('Sauce Labs Backpack');
    await inventory.addItemToCart('Sauce Labs Bike Light');
    await expect(inventory.cartBadge).toHaveText('2');

    await inventory.goToCart();
    await expect(page).toHaveURL(/cart\.html/);
    const itemNames = await cart.getItemNames();
    expect(itemNames).toEqual(
      expect.arrayContaining(['Sauce Labs Backpack', 'Sauce Labs Bike Light'])
    );
    expect(itemNames).toHaveLength(2);

    await cart.checkout();
    await expect(page).toHaveURL(/checkout-step-one\.html/);

    await checkout.fillCustomerInfo('Ada', 'Lovelace', '12345');
    await checkout.continueToOverview();
    await expect(page).toHaveURL(/checkout-step-two\.html/);

    // Confirm the math the app hands back, not just that numbers exist.
    const subtotal = await checkout.getSubtotal();
    const tax = await checkout.getTax();
    const total = await checkout.getTotal();
    expect(total).toBeCloseTo(subtotal + tax, 2);

    await checkout.finish();
    await expect(page).toHaveURL(/checkout-complete\.html/);
    await expect(checkout.completeHeader).toHaveText('Thank you for your order!');
  });
});
