import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { InventoryPage } from '../../pages/InventoryPage';

/**
 * Sauce Demo documents that some accounts "behave incorrectly on
 * purpose." problem_user logs in successfully (so it doesn't belong
 * in login-negative.spec.ts) but every product image is swapped for
 * the same broken/placeholder image. This test pins that known bug
 * down as a named, deliberate assertion instead of letting it show up
 * as a mysterious failure in an unrelated test.
 */
test.describe('Known issues', () => {
  test('problem_user sees identical product images (documented bug)', async ({ page }) => {
    const login = new LoginPage(page);
    const inventory = new InventoryPage(page);

    await login.goto();
    await login.login('problem_user', 'secret_sauce');
    await expect(page).toHaveURL(/inventory\.html/);

    const srcs = await inventory.productImages.evaluateAll((imgs) =>
      imgs.map((img) => (img as HTMLImageElement).src)
    );

    expect(srcs.length).toBeGreaterThan(1);
    const uniqueSrcs = new Set(srcs);
    expect(uniqueSrcs.size).toBe(1); // all images identical -- the known bug
  });
});
