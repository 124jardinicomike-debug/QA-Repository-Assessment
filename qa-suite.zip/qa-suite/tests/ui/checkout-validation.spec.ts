import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { InventoryPage } from '../../pages/InventoryPage';
import { CartPage } from '../../pages/CartPage';
import { CheckoutPage } from '../../pages/CheckoutPage';

/**
 * Unhappy path inside an otherwise-valid session: a logged-in user
 * with items in the cart who doesn't fill in the checkout form
 * correctly. This is UI-layer on purpose -- the validation is
 * client-side JS with no equivalent API endpoint to hit directly.
 */
test.describe('Checkout - form validation', () => {
  test.beforeEach(async ({ page }) => {
    const login = new LoginPage(page);
    const inventory = new InventoryPage(page);
    const cart = new CartPage(page);

    await login.goto();
    await login.login('standard_user', 'secret_sauce');
    await inventory.addItemToCart('Sauce Labs Backpack');
    await inventory.goToCart();
    await cart.checkout();
    await expect(page).toHaveURL(/checkout-step-one\.html/);
  });

  test('blocks submission and reports the first missing field', async ({ page }) => {
    const checkout = new CheckoutPage(page);

    await checkout.continueToOverview();
    await checkout.expectErrorMessage('Error: First Name is required');
    // Still on step one -- validation failure must not leak through.
    await expect(page).toHaveURL(/checkout-step-one\.html/);
  });

  test('reports the next missing field once the first is fixed', async ({ page }) => {
    const checkout = new CheckoutPage(page);

    await checkout.fillCustomerInfo('Ada', '', '');
    await checkout.continueToOverview();
    await checkout.expectErrorMessage('Error: Last Name is required');
    await expect(page).toHaveURL(/checkout-step-one\.html/);
  });

  test('reports missing postal code last', async ({ page }) => {
    const checkout = new CheckoutPage(page);

    await checkout.fillCustomerInfo('Ada', 'Lovelace', '');
    await checkout.continueToOverview();
    await checkout.expectErrorMessage('Error: Postal Code is required');
    await expect(page).toHaveURL(/checkout-step-one\.html/);
  });
});
