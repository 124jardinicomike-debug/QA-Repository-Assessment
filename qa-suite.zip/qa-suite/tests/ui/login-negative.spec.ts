import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';

/**
 * Sauce Demo ships several accounts specifically designed to fail in
 * different ways. locked_out_user is the clearest "unhappy path"
 * built into the app on purpose, so it's the primary negative case
 * here, plus a generic bad-credentials case for good measure.
 */
test.describe('Login - unhappy paths', () => {
  test('locked_out_user is blocked with an explicit error and stays on the login page', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.login('locked_out_user', 'secret_sauce');

    await login.expectErrorMessage('Sorry, this user has been locked out.');
    // Make sure the failure actually prevented navigation -- an error
    // toast with a silent redirect to the app would be worse than no
    // error at all.
    await expect(page).toHaveURL('https://www.saucedemo.com/');
    await expect(page.locator('.inventory_list')).toHaveCount(0);
  });

  test('invalid credentials are rejected with a generic error', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.login('not_a_real_user', 'wrong_password');

    await login.expectErrorMessage(
      'Username and password do not match any user in this service'
    );
    await expect(page).toHaveURL('https://www.saucedemo.com/');
  });

  test('empty credentials are rejected before any request-like navigation', async ({ page }) => {
    const login = new LoginPage(page);

    await login.goto();
    await login.login('', '');

    await login.expectErrorMessage('Username is required');
  });
});
