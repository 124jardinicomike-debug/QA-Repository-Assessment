import { type Page, type Locator } from '@playwright/test';

/**
 * The inventory (product listing) page. Sauce Demo derives each
 * "Add to cart" button id from the product name
 * (e.g. "Sauce Labs Backpack" -> #add-to-cart-sauce-labs-backpack),
 * so we build the locator from the visible product name rather than
 * hardcoding ids everywhere the tests need to add an item.
 */
export class InventoryPage {
  readonly page: Page;
  readonly cartBadge: Locator;
  readonly cartLink: Locator;
  readonly inventoryItems: Locator;
  readonly productImages: Locator;

  constructor(page: Page) {
    this.page = page;
    this.cartBadge = page.locator('.shopping_cart_badge');
    this.cartLink = page.locator('.shopping_cart_link');
    this.inventoryItems = page.locator('.inventory_item');
    this.productImages = page.locator('.inventory_item_img img');
  }

  private addToCartButtonFor(productName: string): Locator {
    const slug = productName.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    return this.page.locator(`#add-to-cart-${slug}`);
  }

  async addItemToCart(productName: string) {
    await this.addToCartButtonFor(productName).click();
  }

  async getCartBadgeCount(): Promise<string | null> {
    if (await this.cartBadge.count() === 0) return null;
    return this.cartBadge.textContent();
  }

  async goToCart() {
    await this.cartLink.click();
  }
}
